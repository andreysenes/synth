VOZ-9 v2 SMT
Gerbers for the 200 x 100 mm board. Upload bom.csv and cpl.csv alongside this zip
and turn PCB Assembly on. J1-J9 are 1.6 mm wire holes (solder the cable
straight in, including an XLR conductor) and D6/D7 (MP20) are not in those
files: solder them by hand.

Layers: 2
Size: 200 mm x 100 mm
Thickness: 1.6 mm
Material: FR-4
Outer copper: 1 oz
Solder mask: green, both sides
Silkscreen: white, both sides
Surface finish: lead-free HASL
Via covering: tented
Impedance control: no
Gold fingers: no
Castellated holes: no

Outline: voz-9-Edge_Cuts.gm1
Drills: Excellon, millimeters, absolute, decimal zeros
PTH: voz-9-PTH.drl (1.6 mm wire holes and two axial diodes)
NPTH: voz-9-NPTH.drl (four M3 mounting holes, 3.2 mm, no copper)

Remove the JLCPCB order number, or place it on the bottom, away from the wire holes.
