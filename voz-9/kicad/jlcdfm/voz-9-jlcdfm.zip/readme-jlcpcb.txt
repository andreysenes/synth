VOZ-9 BASE
Order this as a bare PCB. Parts are through-hole and are not assembled by JLCPCB.

Layers: 2
Size: 300 mm x 140 mm
Thickness: 1.6 mm
Material: FR-4
Outer copper: 1 oz
Solder mask: green, both sides
Silkscreen: white, both sides
Surface finish: lead-free HASL
Via covering: tented
Impedance control: no
Gold fingers: no
Castellated holes: no

Outline: voz-9-Edge_Cuts.gm1
Drills: Excellon, millimeters, absolute, decimal zeros
PTH: voz-9-PTH.drl
NPTH: voz-9-NPTH.drl (four M3 mounting holes, 3.2 mm, no copper)

Remove the JLCPCB order number, or place it on the bottom, away from the pin headers.
